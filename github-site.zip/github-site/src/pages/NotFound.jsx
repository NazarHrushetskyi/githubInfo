import React from 'react'

import NotFoundBlock from '../components/NotFoundBlock'

export const NotFound = () => {
  return <NotFoundBlock /> 
};

export default NotFound;