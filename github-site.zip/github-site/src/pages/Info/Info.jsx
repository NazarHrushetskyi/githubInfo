import React from 'react';
import axios from 'axios';
import Moment from 'react-moment';
import InfoSearch from './InfoSearch';
import Sort from '../../components/Sort';
import { Link, useParams } from 'react-router-dom';

import styles from './Info.module.scss';

const Info = () => {
  const [user, setUser] = React.useState();
  const [repos, setRepos] = React.useState();
  const [text, setText] = React.useState('');
  const [defaultRepos, setDefaultRepos] = React.useState();

  const [sortType, setSortType] = React.useState({
    name: 'alphabet -+',
    sortProperty: 'name',
  });

  const { id } = useParams();
  const sortBy = sortType.sortProperty.replace('-', '');
  const order = sortType.sortProperty.includes('-') ? 'asc' : 'desc';

  async function fetchUsers() {
    try {
      const { data } = await axios.get(`https://api.github.com/users/${id}`);
      setUser(data);
    } catch (error) {
      console.log('API error:', error);
      alert('Помилка під час отримання користувачів(');
    }
  }

  React.useEffect(() => {
    fetchUsers();
  }, []);

  async function getRepos() {
    try {
      const { data } = await axios.get(
        `https://api.github.com/users/${id}/repos?per_page=8&sort=${sortBy}&order=${order}`,
      );
      setRepos(data);
      setDefaultRepos(data);
    } catch (error) {
      console.log('API error:', error);
    }
  }
  React.useEffect(() => {
    getRepos();
  }, []);

  const sortLetter = () => {
    const sorted = repos.sort((a, b) => {
      return a.name - b.name;
    });
    setRepos(sorted);
  };

  const sortLetterReverse = () => {
    const sorted = repos
      .sort((a, b) => {
        return a.name - b.name;
      })
      .reverse();
    setRepos(sorted);
  };

  const sortStar = () => {
    const sorted = repos.sort((a, b) => {
      return +a.stargazers_count - +b.stargazers_count;
    });
    setRepos(sorted);
  };

  const sortStarReverse = () => {
    const sorted = repos
      .sort((a, b) => {
        return +a.stargazers_count - +b.stargazers_count;
      })
      .reverse();
    setRepos(sorted);
  };

  React.useEffect(() => {
    if (repos) {
      const arr = defaultRepos.reduce((acum, item) => {
        return item.name.includes(text) ? [...acum, item] : acum;
      }, []);
      setRepos(arr);
    }
  }, [text]);

  if (!user) {
    return 'Загрузка...';
  }

  if (!repos) {
    return 'Загрузка...';
  }

  if (!user.location) {
    user.location = 'No information';
  }

  return (
    <div className={styles.info_container}>
      <Link key={user.id} to={`/user/${user.login}`}></Link>
      <div className={styles.left_container}>
        <img className={styles.avt_img} src={user.avatar_url} alt="avt_img" />
        <div className={styles.info_block}>
          <p>User name:</p>
          <h2 className={styles.h2}>{user.name}</h2>
          <p>Location:</p>
          <h3 className={styles.h3}>{user.location}</h3>
          <p>Join date:</p>
          <h3 className={styles.h3}>
            <Moment format="M/D/YY">{user.created_at}</Moment>
          </h3>
          <p>Followers:</p>
          <h3 className={styles.h3}>{user.followers} followers</h3>
        </div>
      </div>
      <div className={styles.block}>
        <div className={styles.blatnyi}>
          <Sort
            value={sortType}
            onChangeSort={(i) => {
              setSortType(i);
              switch (i.type) {
                case 'sortLetter':
                  sortLetter();
                  break;
                case 'sortLetterReverse':
                  sortLetterReverse();
                  break;
                case 'sortStar':
                  sortStar();
                  break;
                case 'sortStarReverse':
                  sortStarReverse();
                  break;
                default:
                  sortLetter();
                  break;
              }
            }}
          />
          <InfoSearch value={text} onChange={setText} />
        </div>

        <div className={styles.rep_block}>
          {repos.map((item) => (
            <div className={styles.rep_info}>
              <div className={styles.info1}>
                <div className={styles.rep_name}> {item.name} </div>
                <div className={styles.rep_fork}> {item.forks} forks</div>
              </div>
              <div className={styles.rep_star}>
                <svg
                  className={styles.star}
                  enableBackground="new 0 0 32 32"
                  version="1.1"
                  viewBox="0 0 32 32"
                  xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M30.9,10.6C30.8,10.2,30.4,10,30,10h0h-9l-4.1-8.4C16.7,1.2,16.4,1,16,1v0c0,0,0,0,0,0   c-0.4,0-0.7,0.2-0.9,0.6L11,10H2c-0.4,0-0.8,0.2-0.9,0.6c-0.2,0.4-0.1,0.8,0.2,1.1l6.6,7.6L5,29.7c-0.1,0.4,0,0.8,0.3,1   s0.7,0.3,1.1,0.1l9.6-4.6l9.6,4.6C25.7,31,25.8,31,26,31h0h0h0c0.5,0,1-0.4,1-1c0-0.2,0-0.3-0.1-0.5l-2.8-10.3l6.6-7.6   C31,11.4,31.1,10.9,30.9,10.6z"
                    fill="#FE9803"
                  />
                </svg>
                {item.stargazers_count}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Info;
