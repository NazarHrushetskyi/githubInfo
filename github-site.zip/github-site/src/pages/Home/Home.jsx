import React from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import UserBlock from '../../components/UserBlock/index';
import styles from './home.module.scss';
import { SearchContext } from '../../App';


const Home = () => {
  const {searchValue} = React.useContext(SearchContext);
  const [dataUser, setDataUser] = React.useState();

  async function fetchUsers() {
    try {
      const search = searchValue ? `${searchValue}` : '';
      const { data } = await axios.get(
        `https://api.github.com/search/users?${search.length ? 'q=' + search + '&' : 'q=a' + '&'}per_page=9`,
      );
      setDataUser(data.items);
    } catch (error) {
      console.log('API error:', error);
      alert('Помилка під час отримання користувачів(');
    }
  }

  React.useEffect(() => {
    fetchUsers();
  }, [searchValue]);


  if (!dataUser) {
    return 'data loading...';
  }
  return (
    <div className={styles.pageContainer}>
      {dataUser.map((obj) => (
        <Link key={obj.id} to={`/user/${obj.login}`}>
          <UserBlock data={obj} />
        </Link>
      ))}
    </div>
  );
};

export default Home;
