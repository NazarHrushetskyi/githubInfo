import { configureStore } from '@reduxjs/toolkit';

import user from './slices/userSlice';
import filters from './slices/filterSlice';

export const store = configureStore({
  reducer: {
    user,
    filters,
  },
});
