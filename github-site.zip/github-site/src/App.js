import React from 'react';

import { Routes, Route } from 'react-router-dom';
import MainLayout from './layout/MainLayout.jsx';
import Info from './pages/Info/Info';
import NotFound from './pages/NotFound.jsx';
import Home from './pages/Home/Home';

import './scss/app.scss';

export const SearchContext = React.createContext('');

function App() {
  const [searchValue, setSearchValue] = React.useState('');

  return (
    <SearchContext.Provider value={{searchValue, setSearchValue}}>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route path="" element={<Home />} />
          <Route path="user/:id" element={<Info />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </SearchContext.Provider>
  );
}

export default App;
